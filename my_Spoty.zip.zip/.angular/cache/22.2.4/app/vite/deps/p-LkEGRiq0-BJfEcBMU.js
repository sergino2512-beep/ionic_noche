//#region node_modules/@ionic/core/components/p-Ct2aBEue.js
/*!
* (C) Ionic http://ionicframework.com - MIT License
*/
var n$2 = class {
	constructor() {
		this.m = /* @__PURE__ */ new Map();
	}
	reset(t) {
		this.m = new Map(Object.entries(t));
	}
	get(t, n) {
		const e = this.m.get(t);
		return void 0 !== e ? e : n;
	}
	getBoolean(t, n = !1) {
		const e = this.m.get(t);
		return void 0 === e ? n : "string" == typeof e ? "true" === e : !!e;
	}
	getNumber(t, n) {
		const e = parseFloat(this.m.get(t));
		return isNaN(e) ? void 0 !== n ? n : NaN : e;
	}
	set(t, n) {
		this.m.set(t, n);
	}
};
var e = new n$2();
var u;
(function(t) {
	t.OFF = "OFF", t.ERROR = "ERROR", t.WARN = "WARN", t.DEBUG = "DEBUG";
})(u || (u = {}));
var f$1 = {
	[u.OFF]: 0,
	[u.ERROR]: 1,
	[u.WARN]: 2,
	[u.DEBUG]: 3
};
var a = (t) => {
	return f$1[String(e.get("logLevel", u.WARN)).toUpperCase()] >= f$1[t];
};
var d$1 = (t, ...n) => {
	if (a(u.WARN)) return console.warn(`[Ionic Warning]: ${t}`, ...n);
};
var h = (t, ...n) => {
	if (a(u.ERROR)) return console.error(`[Ionic Error]: ${t}`, ...n);
};
var $ = ((t) => (t.Undefined = "undefined", t.Null = "null", t.String = "string", t.Number = "number", t.SpecialNumber = "number", t.Boolean = "boolean", t.BigInt = "bigint", t))($ || {});
var b = ((t) => (t.Array = "array", t.Date = "date", t.Map = "map", t.Object = "object", t.RegularExpression = "regexp", t.Set = "set", t.Channel = "channel", t.Symbol = "symbol", t))(b || {});
var N = (t) => {
	if (t.__stencil__getHostRef) return t.__stencil__getHostRef();
};
var x = (t, n) => (0, console.error)(t, n);
var A$1 = "undefined" != typeof window ? window : {};
A$1.HTMLElement;
var B = {
	i: 0,
	u: "",
	jmp: (t) => t(),
	raf: (t) => requestAnimationFrame(t),
	ael: (t, n, e, o) => t.addEventListener(n, e, o),
	rel: (t, n, e, o) => t.removeEventListener(n, e, o),
	ce: (t, n) => new CustomEvent(t, n)
};
(() => {
	var t;
	let n = !1;
	try {
		null == (t = A$1.document) || t.addEventListener("e", null, Object.defineProperty({}, "passive", { get() {
			n = !0;
		} }));
	} catch (t) {}
	return n;
})();
(() => {
	try {
		return !!A$1.document.adoptedStyleSheets && (new CSSStyleSheet(), "function" == typeof new CSSStyleSheet().replaceSync);
	} catch (t) {}
	return !1;
})() && (() => !!A$1.document && Object.getOwnPropertyDescriptor(A$1.document.adoptedStyleSheets, "length").writable)();
var D = [];
var W = [];
var V = () => {
	var t;
	return (null == (t = A$1.document) ? void 0 : t.hidden) ? setTimeout(q, 16) : B.raf(q);
};
var P = (t) => {
	for (let n = 0; n < t.length; n++) try {
		t[n](performance.now());
	} catch (t) {
		x(t);
	}
	t.length = 0;
};
var q = () => {
	P(D), P(W), D.length > 0 && V();
};
var zt = (t) => {
	var n;
	return null == (n = N(t)) ? void 0 : n.A;
};
//#endregion
//#region node_modules/@ionic/core/components/p-ZjP4CjeZ.js
/*!
* (C) Ionic http://ionicframework.com - MIT License
*/
var d = "undefined" != typeof window ? window : void 0;
var o = "undefined" != typeof document ? document : void 0;
//#endregion
//#region node_modules/@ionic/core/components/p-ChsJlFCQ.js
/*!
* (C) Ionic http://ionicframework.com - MIT License
*/
var t$1;
var i = (e, o, i) => {
	const n = o.startsWith("animation") ? (r = e, void 0 === t$1 && (t$1 = void 0 === r.style.animationName && void 0 !== r.style.webkitAnimationName ? "-webkit-" : ""), t$1) : "";
	var r;
	e.style.setProperty(n + o, i);
};
var n$1 = (e = [], o) => {
	if (void 0 !== o) {
		const t = Array.isArray(o) ? o : [o];
		return [...e, ...t];
	}
	return e;
};
var r$1 = (t) => {
	let r, a, s, d$3, f, l, c, v, m, u, p, y = [], g = [], A = [], b = !1, C = {}, E = [], h$2 = [], S = {}, k = 0, R = !1, j = !1, w = !0, T = !1, D = !0, F = !1;
	const W = t, I = [], K = [], M = [], P = [], Z = [], x = [], B = [], q = [], z = [], G = [], H = [], J = "function" == typeof AnimationEffect || void 0 !== d && "function" == typeof d.AnimationEffect, L = "function" == typeof Element && "function" == typeof Element.prototype.animate && J, N = () => H, O = (e, o) => {
		const t = o.findIndex(((o) => o.c === e));
		t > -1 && o.splice(t, 1);
	}, Q = (e, o) => ((o?.oneTimeCallback ? K : I).push({
		c: e,
		o
	}), p), U = () => {
		L && (H.forEach(((e) => {
			e.cancel();
		})), H.length = 0);
	}, V = () => {
		x.forEach(((e) => {
			e?.parentNode && e.parentNode.removeChild(e);
		})), x.length = 0;
	}, X = () => void 0 !== f ? f : c ? c.getFill() : "both", Y = () => void 0 !== v ? v : void 0 !== l ? l : c ? c.getDirection() : "normal", $ = () => R ? "linear" : void 0 !== s ? s : c ? c.getEasing() : "linear", _ = () => j ? 0 : void 0 !== m ? m : void 0 !== a ? a : c ? c.getDuration() : 0, ee = () => void 0 !== d$3 ? d$3 : c ? c.getIterations() : 1, oe = () => void 0 !== u ? u : void 0 !== r ? r : c ? c.getDelay() : 0, te = () => {
		0 !== k && (k--, 0 === k && ((() => {
			z.forEach(((e) => e())), G.forEach(((e) => e()));
			const e = w ? 1 : 0, o = E, t = h$2, n = S;
			P.forEach(((e) => {
				const r = e.classList;
				o.forEach(((e) => r.add(e))), t.forEach(((e) => r.remove(e)));
				for (const o in n) n.hasOwnProperty(o) && i(e, o, n[o]);
			})), m = void 0, v = void 0, u = void 0, I.forEach(((o) => o.c(e, p))), K.forEach(((o) => o.c(e, p))), K.length = 0, D = !0, w && (T = !0), w = !0;
		})(), c && c.animationFinish()));
	}, ie = () => {
		(() => {
			B.forEach(((e) => e())), q.forEach(((e) => e()));
			const e = g, o = A, t = C;
			P.forEach(((n) => {
				const r = n.classList;
				e.forEach(((e) => r.add(e))), o.forEach(((e) => r.remove(e)));
				for (const e in t) t.hasOwnProperty(e) && i(n, e, t[e]);
			}));
		})(), y.length > 0 && L && (P.forEach(((e) => {
			const o = e.animate(y, {
				id: W,
				delay: oe(),
				duration: _(),
				easing: $(),
				iterations: ee(),
				fill: X(),
				direction: Y()
			});
			o.pause(), H.push(o);
		})), H.length > 0 && (H[0].onfinish = () => {
			te();
		})), b = !0;
	}, ne = (e) => {
		e = Math.min(Math.max(e, 0), .9999), L && H.forEach(((o) => {
			o.currentTime = o.effect.getComputedTiming().delay + _() * e, o.pause();
		}));
	}, re = (e) => {
		H.forEach(((e) => {
			e.effect.updateTiming({
				delay: oe(),
				duration: _(),
				easing: $(),
				iterations: ee(),
				fill: X(),
				direction: Y()
			});
		})), void 0 !== e && ne(e);
	}, ae = (e = !1, o = !0, t) => (e && Z.forEach(((i) => {
		i.update(e, o, t);
	})), L && re(t), p), se = () => {
		b && (L ? H.forEach(((e) => {
			e.pause();
		})) : P.forEach(((e) => {
			i(e, "animation-play-state", "paused");
		})), F = !0);
	}, de = (e) => new Promise(((o) => {
		e?.sync && (j = !0, Q((() => j = !1), { oneTimeCallback: !0 })), b || ie(), T && (L && (ne(0), re()), T = !1), D && (k = Z.length + 1, D = !1);
		const t = () => {
			O(i, K), o();
		}, i = () => {
			O(t, M), o();
		};
		Q(i, { oneTimeCallback: !0 }), M.push({
			c: t,
			o: { oneTimeCallback: !0 }
		}), Z.forEach(((e) => {
			e.play();
		})), L ? (H.forEach(((e) => {
			e.play();
		})), 0 !== y.length && 0 !== P.length || te()) : te(), F = !1;
	})), fe = (e, o) => {
		const t = y[0];
		return void 0 === t || void 0 !== t.offset && 0 !== t.offset ? y = [{
			offset: 0,
			[e]: o
		}, ...y] : t[e] = o, p;
	};
	return p = {
		parentAnimation: c,
		elements: P,
		childAnimations: Z,
		id: W,
		animationFinish: te,
		from: fe,
		to: (e, o) => {
			const t = y[y.length - 1];
			return void 0 === t || void 0 !== t.offset && 1 !== t.offset ? y = [...y, {
				offset: 1,
				[e]: o
			}] : t[e] = o, p;
		},
		fromTo: (e, o, t) => fe(e, o).to(e, t),
		parent: (e) => (c = e, p),
		play: de,
		pause: () => (Z.forEach(((e) => {
			e.pause();
		})), se(), p),
		stop: () => {
			Z.forEach(((e) => {
				e.stop();
			})), b && (U(), b = !1), R = !1, j = !1, D = !0, v = void 0, m = void 0, u = void 0, k = 0, T = !1, w = !0, F = !1, M.forEach(((e) => e.c(0, p))), M.length = 0;
		},
		destroy: (e) => (Z.forEach(((o) => {
			o.destroy(e);
		})), ((e) => {
			U(), e && V();
		})(e), P.length = 0, Z.length = 0, y.length = 0, I.length = 0, K.length = 0, b = !1, D = !0, p),
		keyframes: (e) => {
			const o = y !== e;
			return y = e, o && ((e) => {
				L && N().forEach(((o) => {
					const t = o.effect;
					if (t.setKeyframes) t.setKeyframes(e);
					else o.effect = new KeyframeEffect(t.target, e, t.getTiming());
				}));
			})(y), p;
		},
		addAnimation: (e) => {
			if (null != e) if (Array.isArray(e)) for (const o of e) o.parent(p), Z.push(o);
			else e.parent(p), Z.push(e);
			return p;
		},
		addElement: (o) => {
			if (null != o) if (1 === o.nodeType) P.push(o);
			else if (o.length >= 0) for (let e = 0; e < o.length; e++) P.push(o[e]);
			else h("createAnimation - Invalid addElement value.");
			return p;
		},
		update: ae,
		fill: (e) => (f = e, ae(!0), p),
		direction: (e) => (l = e, ae(!0), p),
		iterations: (e) => (d$3 = e, ae(!0), p),
		duration: (e) => (L || 0 !== e || (e = 1), a = e, ae(!0), p),
		easing: (e) => (s = e, ae(!0), p),
		delay: (e) => (r = e, ae(!0), p),
		getWebAnimations: N,
		getKeyframes: () => y,
		getFill: X,
		getDirection: Y,
		getDelay: oe,
		getIterations: ee,
		getEasing: $,
		getDuration: _,
		afterAddRead: (e) => (z.push(e), p),
		afterAddWrite: (e) => (G.push(e), p),
		afterClearStyles: (e = []) => {
			for (const o of e) S[o] = "";
			return p;
		},
		afterStyles: (e = {}) => (S = e, p),
		afterRemoveClass: (e) => (h$2 = n$1(h$2, e), p),
		afterAddClass: (e) => (E = n$1(E, e), p),
		beforeAddRead: (e) => (B.push(e), p),
		beforeAddWrite: (e) => (q.push(e), p),
		beforeClearStyles: (e = []) => {
			for (const o of e) C[o] = "";
			return p;
		},
		beforeStyles: (e = {}) => (C = e, p),
		beforeRemoveClass: (e) => (A = n$1(A, e), p),
		beforeAddClass: (e) => (g = n$1(g, e), p),
		onFinish: Q,
		isRunning: () => 0 !== k && !F,
		progressStart: (e = !1, o) => (Z.forEach(((t) => {
			t.progressStart(e, o);
		})), se(), R = e, b || ie(), ae(!1, !0, o), p),
		progressStep: (e) => (Z.forEach(((o) => {
			o.progressStep(e);
		})), ne(e), p),
		progressEnd: (e, o, t) => (R = !1, Z.forEach(((i) => {
			i.progressEnd(e, o, t);
		})), void 0 !== t && (m = t), T = !1, w = !0, 0 === e ? (v = "reverse" === Y() ? "normal" : "reverse", "reverse" === v && (w = !1), L ? (ae(), ne(1 - o)) : (u = (1 - o) * _() * -1, ae(!1, !1))) : 1 === e && (L ? (ae(), ne(o)) : (u = o * _() * -1, ae(!1, !1))), void 0 === e || c || de(), p)
	};
};
//#endregion
//#region node_modules/@ionic/core/components/p-CUQjkOdi.js
var n = (a, i) => {
	/*!
	* (C) Ionic http://ionicframework.com - MIT License
	*/
	a.componentOnReady ? a.componentOnReady().then(((a) => i(a))) : f((() => i(a)));
};
var f = (a) => "function" == typeof __zone_symbol__requestAnimationFrame ? __zone_symbol__requestAnimationFrame(a) : "function" == typeof requestAnimationFrame ? requestAnimationFrame(a) : setTimeout(a);
//#endregion
//#region node_modules/@ionic/core/components/p-LkEGRiq0.js
/*!
* (C) Ionic http://ionicframework.com - MIT License
*/
var t = "ionViewWillEnter";
var r = "ionViewDidEnter";
var s = "ionViewWillLeave";
var c = "ionViewDidLeave";
var l = "ionViewWillUnload";
var A = (n) => {
	if (n.classList.contains("ion-page")) return n;
	return n.querySelector(":scope > .ion-page, :scope > ion-nav, :scope > ion-tabs") || n;
};
//#endregion
export { s as a, r$1 as c, e as d, zt as f, r as i, o as l, c as n, t as o, l as r, n as s, A as t, d$1 as u };
